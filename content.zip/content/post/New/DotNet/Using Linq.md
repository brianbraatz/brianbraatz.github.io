---
title: Using Linq
date: 2025-01-27T13:55:26.374Z
lastmod: 2025-01-27T12:44:43.998Z
---
here is how to use linq

you should check out linq1 and linq2

here is the code

you can download at my toolkit link here\
(link to dotnettoolkit)

the toolkit is

\[[Language Integrated Query (LINQ) - C# | Microsoft Learn](https://learn.microsoft.com/en-us/dotnet/csharp/linq/)]\([Language Integrated Query (LINQ) - C# | Microsoft Learn](https://learn.microsoft.com/en-us/dotnet/csharp/linq/))
